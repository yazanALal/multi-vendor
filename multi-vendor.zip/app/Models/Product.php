<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable=[
        'name',
        'store_id',
        'price',
        'category',
        'description',
        'price_type',
        'uuid',
        'condition',
        'delivery_details',
        'sales_price',
        'images',
        'location',
    ];

    protected $casts = [
        'name'=>'string',
        'store_id'=>'integer',
        'price'=>'float',
        'category' => 'string',
        'description' => 'string',
        'price_type' => 'string',
        'uuid' => 'string',
        'condition' => 'string',
        'delivery_details' => 'string',
        'sales_price'=>'float',
        'images' => 'json',
        'location' => 'string',
    ];

    public function store():object {
        return $this->belongsTo(Store::class);
    }
    
    public function orderItems():object {
        return $this->hasMany(OrderItem::class);
    }
}
