<?php

namespace App\Http\Enums;

enum OrderStatus: string
{
    case order_placed = 'order_placed';
    case payment_confirmed = 'payment_confirmed';
    case processed = 'processed';
    case delivered = 'delivered';
}
