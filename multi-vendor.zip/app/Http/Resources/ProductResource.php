<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'name'=>$this->name,
            'category'=>$this->category,
            'price'=>$this->price,
            'sales_price'=>$this->sales_price,
            'description'=>$this->description,
            'price_type'=>$this->price_type,
            'uuid'=>$this->uuid,
            'condition'=>$this->condition,
            'delivery_details'=>$this->delivery_details,
            'images'=>$this->images,
            'location'=>$this->location,
        ];
    }
}
